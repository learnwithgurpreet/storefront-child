<?php
function storefront_child_enqueue_styles() {
  wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'storefront_child_enqueue_styles' );

function storefront_child_check_for_updates() {
  $theme = wp_get_theme();
  $theme_name = $theme->get('Name');
  print($theme_name);
  die();
  $theme_version = $theme->get('Version');
  $update_url = 'https://learnwithgurpreet.github.io/storefront-child/update.json'; // Replace with your custom update API URL

  // Make the request to the update API
  $request = wp_remote_get($update_url, array(
    'timeout' => 10,
    'headers' => array(
      'Accept' => 'application/json',
    ),
    'body' => array(
      'theme' => $theme_name,
      'version' => $theme_version,
    ),
  ));

  if (!is_wp_error($request) && wp_remote_retrieve_response_code($request) === 200) {
    $response = json_decode(wp_remote_retrieve_body($request), true);

    // Check if an update is available
    if (isset($response['update_available']) && $response['update_available']) {
      $download_link = $response['download_link'];
      $new_version = $response['new_version'];
      
      // Display update notification in the admin dashboard
      add_action('admin_notices', function() use ($download_link, $new_version) {
        $update_message = sprintf(
          'A new version (%s) of the theme is available. <a href="%s">Click here</a> to update.',
          $new_version,
          $download_link
        );
          echo '<div class="notice notice-info"><p>' . $update_message . '</p></div>';
        });
      }
    }
}
add_action('admin_init', 'storefront_child_check_for_updates');

?>
